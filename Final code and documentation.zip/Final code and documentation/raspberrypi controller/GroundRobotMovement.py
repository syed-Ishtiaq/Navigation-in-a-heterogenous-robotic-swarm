import serial



def robotMovementRight():
  ser = serial.Serial('/dev/ttyUSB0', 9600)
  while 1:
    ser.write(b"R\n") 
    if(ser.in_waiting >0):
        line = ser.readline()
        print(line)


def robotMovementLeft():
  ser = serial.Serial('/dev/ttyUSB0', 9600)
  while 1:
    ser.write(b"L\n") 
    if(ser.in_waiting >0):
        line = ser.readline()
        print(line)


def robotMovementForward():
  ser = serial.Serial('/dev/ttyUSB0', 9600)
  while 1:
    ser.write(b"F\n") 
    if(ser.in_waiting >0):
        line = ser.readline()
        print(line)


def robotMovementBackward():
  ser = serial.Serial('/dev/ttyUSB0', 9600)
  while 1:
    ser.write(b"B\n") 
    if(ser.in_waiting >0):
        line = ser.readline()
        print(line)


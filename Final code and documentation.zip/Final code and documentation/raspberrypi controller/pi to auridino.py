void setup() {
  Serial.begin(9600);
}
void loop() {
  
  String data = Serial.readStringUntil('\n');
  Serial.println("command recived");
  Serial.print(data);
  delay(1000);
}







import serial
ser = serial.Serial('/dev/ttyUSB0', 9600)
while 1: 
    ser.write(b"readings\n")
    if(ser.in_waiting >0):
        line = ser.readline()
        print(line)
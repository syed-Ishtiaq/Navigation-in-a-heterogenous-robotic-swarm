import barcode
import cv2
from pyzbar.pyzbar import decode
from pyzbar.pyzbar import Decoded

hr=barcode.get_barcode_class('ean13')     //getting the class of the barcode

Hr=hr('1234567891012')                 //information to store in the barcode
 
qr=Hr.save('now created')   

 
image = cv2.imread('C:/Users/N/Desktop/barcode.png')     // reading the image from the directory

detectedBarcodes = decode(image)                        //decoding the image
  
cv2.imshow("Image", image)                            //showing the barcode image
  
print(detectedBarcodes)        
import serial


def readingHumidity():
  ser = serial.Serial('/dev/ttyUSB0', 9600)
  while 1: 
    ser.write(b"Humidity\n")
    if(ser.in_waiting >0):
        line = ser.readline()
        print(line)



def readingTemperature():
  ser = serial.Serial('/dev/ttyUSB0', 9600)
  while 1: 
    ser.write(b"Temperature\n")
    if(ser.in_waiting >0):
        line = ser.readline()
        print(line)